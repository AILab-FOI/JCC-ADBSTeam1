If database with all tables already exists, ignore script 0 and just execute scripts 1-5 in order.

If database doesn't yet exist, create a blank new one and restore it from script 0. After that, execure scripts 1-5 in order in query tool.

WARNING!!! - Executing these scripts (script 1 to be exact) will truncate and reset identity on ALL tables.